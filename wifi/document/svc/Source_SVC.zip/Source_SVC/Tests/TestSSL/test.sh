while [ true ]
do
	./bin/server
done
